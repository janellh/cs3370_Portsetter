incorrect flag

Usage: portsetter [OPTION]... [PORTNUMBER]...

opens port specifies and prints a listening message to user

Mandatory arguments to long options are mandatory for short options too.

-p,  --port      opens port

-h,  --help  -?  displays this help and exits

-!,  --about     prints out information on programmer.

-v, --version    prints out version number of program.

-p -e            prints out default port if none is given.

Exit Status:
    0 if Ok
    1 incorrect arguments
    2 incorrect flag
    3 port number out of range

