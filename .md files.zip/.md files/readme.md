to run program
    1. make portsetter
    2. setport [flag] [port_number]
    3. for help use flag -h
    
to change setting in bash to spanish
    1. export LANGUAGE=en_US
        i. that is the default if you want to change other options change var 
    