﻿
Uso: portsetter [OPCIÓN] ... [PORTNUMBER] ...

especifica el puerto se abre e imprime un mensaje al usuario escucha

Los argumentos obligatorios para las opciones largas son obligatorios 
para las opciones cortas también

-p,  --port      abre el puerto

-h,  --help  -?  Muestra esta ayuda y salidas

-!,  --about     imprime información sobre el programador

-v, --version    imprime el número de versión del programa.

-p -e            imprime puerto por defecto si no se da ninguno.

Estado de salida:
    0 bueno
    1 argumentos incorrectos
    2 indicador incorrecto
    3 número de puerto fuera de rango